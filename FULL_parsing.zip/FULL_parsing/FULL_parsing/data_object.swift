//
//  celllTableViewCell.swift
//  FULL_parsing
//
//  Created by m on 8/30/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit
class Repository
{
    
    var name: String?
    var time: String?
    var describtion: String?
    
    init(json: NSDictionary) {
        self.name = json["TITLE"] as? String
        self.time = json["TIME"] as? String
        self.describtion = json["DETAILS"] as? String
    }
}


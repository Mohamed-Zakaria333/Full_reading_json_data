//
//  celllTableViewCell.swift
//  FULL_parsing
//
//  Created by m on 8/30/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit

class celll: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var desc: UITextView!
    @IBOutlet weak var imagee: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
   
    }


     override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }



}

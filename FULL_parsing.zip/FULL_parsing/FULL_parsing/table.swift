//
//  table.swift
//  FULL_parsing
//
//  Created by m on 8/30/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit

class table: UITableViewController {
var repositories = [Repository]()
 var daaays = [String]()

    
 var imgData = [Data]()
var imgnames = ["1","2","3","4","5","6"]
    override func viewDidLoad() {
        super.viewDidLoad()
        jsonParsingFromFile(FileName: "days" , Extention: "json")
        jsonParsingFromFile2(FileName: imgnames , Extention: "jpg")
        func preferredStatusBarStyle() -> UIStatusBarStyle {
            return .lightContent
        }
        tableView.reloadData()
        
        
    }
    
    
  
    
    
    func jsonParsingFromURL (theurl: String) {
        guard let url = URL(string: theurl)else {return}
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil
            {
                print("Error")
            }
            else
            {
                print("==================================")
                print(response ?? URLResponse())
                print("==================================")
                if let content = data
                {
                    do
                    {
                        self.startParsing(data: content)
                    }
                    catch
                    {
                    print("==================================")
                    print("sorry there is an error Try to dicover it !")
                    print("==================================")
                    }
                
                }
            }
        }
        task.resume()
    }
    
    func jsonParsingFromFile(FileName: String , Extention: String)
    {
        let dataURL = Bundle.main.url(forResource: FileName, withExtension: Extention)!
        
       
        let data = try? Data(contentsOf: dataURL, options: .mappedRead)
        
        if let content = data
        {
            do
            {
                self.startParsing(data: content)
            }
            catch
            {
                print("==================================")
                print("sorry there is an error Try to dicover it !")
                print("==================================")
            }
            
        }
        
    }
    func jsonParsingFromFile2(FileName: [String] , Extention: String)
    {
        
        for name in FileName
            {
        let dataURL = Bundle.main.url(forResource: name, withExtension: Extention)!
        let data = try? Data(contentsOf: dataURL, options: .mappedRead)
                print("//////////////////")
                print(data!)
                print("//////////////////")
                imgData.append(data!)
                
            }
    
        }
    //we change in this metod to adabt with our project
    func startParsing(data : Data)
    {
        let Retrivied = try! JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String: Any]
        for (key,valu) in Retrivied
        {
            print(key)
            daaays.append(key)
            print ("==========================")
            let myval = valu as! [NSDictionary]

            for s in myval
            {
                repositories.append(Repository(json: s))
                print(s["TITLE"] as! String)
                print("*****")
                print(s["SPEAKER"] as! String)
                print("*****")
                print(s["TIME"] as! String)
                print("*****")
                print(s["ROOM"] as! String)
                print("*****")
                print(s["DETAILS"] as! String)
                print("<<<<<<<<<*****>>>>>>>>>")
            }
         print ("==========================")
        }
     // print(Retrivied)
    }
    
    
    


    override func numberOfSections(in tableView: UITableView) -> Int {

        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

     return  imgnames.count
        
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cel = tableView.dequeueReusableCell(withIdentifier: "medo", for: indexPath) as! celll
        cel.name.text = repositories[indexPath.row].name
        cel.time.text = repositories[indexPath.row].time
        cel.desc.text = repositories[indexPath.row].describtion
        cel.imagee.image = UIImage(data: imgData[indexPath.row])
        return cel
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 196
    }

}
